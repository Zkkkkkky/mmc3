---
name: git-add-commit-push
description: Summarize the current Git workspace into a persistent commit log, stage all changes, create one commit, and push the current branch when the user explicitly requests the complete add-commit-push operation. Do not use for commit-only, push-only, or ambiguous Git requests.
---

# Git Add Commit Push

Complete the requested repository handoff as one workflow while keeping each Git mutation explicit and observable.

## Authorization boundary

Treat an explicit invocation of this skill, or an unambiguous request containing add, commit, and push, as authorization for those three operations in the current repository. It does not authorize force-pushing, amending, bypassing hooks, pulling, rebasing, merging, deleting, or rewriting history.

Do not infer push authorization from language that asks only to save, stage, or commit changes.

## Workflow

1. Read the current branch, concise status, configured remotes, upstream state, and current `HEAD`. Stop if the repository is in a conflicted merge/rebase state or on a detached HEAD.
2. Briefly tell the user what will be staged and which branch will be pushed. Preserve every workspace file exactly as found except for the required commit-log append.
3. If the workspace or index contains changes, inspect the relevant tracked, staged, and untracked content closely enough to explain both what changed and how it was implemented. Choose the commit message before writing the log:
   - Use the user's commit message verbatim when supplied.
   - Otherwise infer a concise imperative message from the complete pending diff and nearby commit style.
4. Append one traceable entry to `提交记录.md` in the repository root, using `apply_patch` rather than a shell redirection:
   - If the file does not exist, create it with the top-level heading `# 提交记录` followed by the first entry.
   - If it exists, preserve all prior text and append the new entry after a blank line. Never rewrite, reorder, summarize, or deduplicate committed history.
   - Use this entry shape, expanding the bullet lists as needed:

     ```markdown
     ## YYYY-MM-DD HH:mm:ss ±HH:mm — <commit message>

     - 分支：`<branch>`
     - 基线提交：`<full HEAD before this commit>`
     - 改了什么：
       - <observable behavior, data, documentation, or artifact change>
     - 怎么改的：
       - <implementation approach and important technical decisions>
     - 影响范围：
       - `<important path or component>`
     - 验证：
       - <commands and results, or clearly state that validation was not run>
     ```

   - Base every statement on inspected diffs or command results. Do not claim tests or validation that did not run.
   - Summarize the actual work, not the mechanical update to `提交记录.md` itself.
   - The containing Git commit is the trace identity for the entry. Record the full pre-commit `HEAD` as the baseline and report the resulting hash after commit; do not try to embed the resulting commit hash inside its own content.
   - Create exactly one entry for each new commit. If a failed earlier attempt left the same entry uncommitted, update that pending entry instead of appending a duplicate, while preserving any unrelated user edits to the file.
5. Run `git add -A` from the repository root so the commit-log update is staged with every pre-existing workspace change.
6. Confirm the index contains changes, then run `git commit -m <message>` without bypassing hooks. If there were no workspace or index changes at step 3, do not create or modify `提交记录.md` and do not create an empty commit; continue so existing unpushed commits can still be published.
7. Push the current branch:
   - When it already has an upstream, run `git push`.
   - Otherwise use `origin` when present, or the sole configured remote, and run `git push --set-upstream <remote> <branch>`.
   - If there is no usable remote or multiple remotes with no clear choice, stop and ask the user to select one.
8. Verify the command succeeded with concise status and the latest commit, then report the branch, commit hash/message, commit-log path, and push result.

Run the Git commands directly rather than through a generated wrapper script so command-level permissions remain visible. Execute mutations sequentially and stop immediately when one fails; never push after a failed commit.

Do not add unrelated linting, whitespace checks, tests, or content rewrites to this workflow unless the user asks for them. If a hook fails or the remote rejects the push, preserve the resulting state and report the exact blocker rather than automatically changing history or integrating remote changes.
